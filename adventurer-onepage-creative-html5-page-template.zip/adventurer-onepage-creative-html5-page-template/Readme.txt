== Theme Name: Adventurer - One Page Creative HTML5 Page Template

== Copyright (c) 2016 BootstrapThemes.co

== http://BootstrapThemes.co


Html Created by: http://bootstrapthemes.co



Psd Created by: --Ehsnul Islam Moin-- https://www.behance.net/gallery/32618985/ADVENTURER-One-Page-Creative-Template-Free-Download


Rights: 
You are permitted to use the resources for any number of personal and commercial projects.
You may modify the resources according to your requirements and include them into works, 
such as websites, applications or other materials intended for sale. No attribution or 
link back to this site is required, however any credit will be much appreciated.


Prohibitions:
You do not have the rights to redistribute, resell, lease, license, sublicense or offer 
files downloaded from http://bootstrapthemes.co to any third party �as is� or as a separate attachment 
from any of your work. If you wish to promote my resources on your site, you must link back 
to the resource page where users can find the download and not directly to the download file.



If you would like to share one of my resources, you can do so by making a link to the specific 
resource on http://bootstrapthemes.co , you can if you wish insert the embed code for the product previews images to illustrate your link. 
No HOTLINKING is allowed i.e. you cannot make a direct link to the download or/and the images hosted on http://bootstrapthemes.co

Concerning blog posts, you are free to link to it from any website, 
but you cannot however publish it as it is, without prior consent from http://bootstrapthemes.co